#1. Total number of customers available in the database?
SELECT COUNT(DISTINCT `Customer ID`) AS Total_Customers 
FROM customer_information;

#2. Total number of policies issued?
SELECT COUNT(`Policy ID`) AS Total_Policies_Issued 
FROM policy_details;

#3 Total claim amount generated from all policies?
SELECT ROUND(SUM(`Claim Amount`) / 1000000, 2) AS Total_Claim_Amount_Million
FROM claims;

#4 Average coverage amount per policy?
SELECT ROUND(AVG(`Coverage Amount`), 2) AS Avg_Coverage_Amount 
FROM policy_details;

#5 Average premium amount collected per policy?
SELECT ROUND(AVG(`Premium Amount`), 2) AS Avg_Premium_Amount 
FROM policy_details;

#6 What percentage of policies are currently active?
SELECT 
   ROUND(
    COUNT(CASE WHEN `Status` = 'Active' THEN 1 END) * 100.0 / COUNT(*),
    2
) AS Active_Policy_Percentage
FROM policy_details;

#7 How many policies are in active, lapsed, and terminated status?
SELECT `Status`, COUNT(*) AS Policy_Count 
FROM policy_details 
GROUP BY `Status`
ORDER BY Policy_Count DESC;

#8 Which policy status has the highest number of policies?
SELECT `Status`, COUNT(*) AS Policy_Count 
FROM policy_details 
GROUP BY `Status` 
ORDER BY Policy_Count DESC 
LIMIT 1;

#9. What is the ratio between active policies and inactive policies?

SELECT 
    COUNT(CASE WHEN `Status` = 'Active' THEN 1 END) AS Active_Count,
    COUNT(CASE WHEN `Status` <> 'Active' THEN 1 END) AS Inactive_Count,
    ROUND(
        COUNT(CASE WHEN `Status` = 'Active' THEN 1 END) * 1.0 /
        COUNT(CASE WHEN `Status` <> 'Active' THEN 1 END),
        2
    ) AS Active_to_Inactive_Ratio
FROM policy_details;

#10 Which age group has the highest number of policies?
SELECT 
    CASE 
        WHEN Age < 30 THEN 'Under 30'
        WHEN Age BETWEEN 30 AND 50 THEN '30-50'
        ELSE 'Above 50'
    END AS Age_Group,
    COUNT(*) AS Policy_Count
FROM customer_information c
JOIN policy_details p ON c.`Customer ID` = p.`Customer ID`
GROUP BY Age_Group
ORDER BY Policy_Count DESC
LIMIT 1;

#11. Identify the top three age groups by policy count.
SELECT 
    CASE 
        WHEN Age < 30 THEN 'Under 30'
        WHEN Age BETWEEN 30 AND 50 THEN '30-50'
        ELSE 'Above 50'
    END AS Age_Group,
    COUNT(*) AS Policy_Count
FROM customer_information c
JOIN policy_details p ON c.`Customer ID` = p.`Customer ID`
GROUP BY Age_Group
ORDER BY Policy_Count DESC
LIMIT 3;

#12 Which gender has the highest policy participation?
SELECT 
    c.Gender,
    COUNT(*) AS Policy_Count
FROM customer_information c
JOIN policy_details p 
    ON c.`Customer ID` = p.`Customer ID`
GROUP BY c.Gender
ORDER BY Policy_Count DESC
LIMIT 1;

#13 What is the difference between male and female policy counts?
SELECT 
    ABS(COUNT(CASE WHEN Gender = 'Male' THEN 1 END) - 
        COUNT(CASE WHEN Gender = 'Female' THEN 1 END)) AS Male_Female_Difference
FROM customer_information c
JOIN policy_details p ON c.`Customer ID` = p.`Customer ID`;

#14 Which policy type has the maximum number of policies?
SELECT `Policy Type`, COUNT(*) AS Policy_Count 
FROM policy_details 
GROUP BY `Policy Type` 
ORDER BY Policy_Count DESC 
LIMIT 1;

#15 Which policy type has the minimum number of policies?
SELECT `Policy Type`, COUNT(*) AS Policy_Count 
FROM policy_details 
GROUP BY `Policy Type` 
ORDER BY Policy_Count ASC 
LIMIT 1;

#16 Compare Auto and Health policy counts.
SELECT `Policy Type`, COUNT(*) AS Policy_Count 
FROM policy_details 
WHERE `Policy Type` IN ('Auto', 'Health')
GROUP BY `Policy Type`;

#17 What is the total number of policies across all policy types?
SELECT IFNULL(`Policy Type`, 'Grand Total') AS Policy_Type, COUNT(*) AS Total_Policies
FROM policy_details
GROUP BY `Policy Type` WITH ROLLUP;

#18 What is the average premium growth rate over all years?
WITH Yearly_Premium AS (
    SELECT 
        YEAR(`Policy Start Date`) AS Policy_Year,
        SUM(`Premium Amount`) AS Total_Premium
    FROM policy_details
    GROUP BY YEAR(`Policy Start Date`)
),
Growth_Calculation AS (
    SELECT 
        Policy_Year,
        Total_Premium,
        LAG(Total_Premium) OVER (ORDER BY Policy_Year) AS Previous_Year_Premium
    FROM Yearly_Premium
)
SELECT
    ROUND(
        AVG(
            ((Total_Premium - Previous_Year_Premium)
            / Previous_Year_Premium) * 100
        ), 2
    ) AS Average_Premium_Growth_Rate
FROM Growth_Calculation
WHERE Previous_Year_Premium IS NOT NULL;


#19 Is the premium growth trend increasing or decreasing over time?
WITH Yearly_Premium AS (
    SELECT YEAR(`Policy Start Date`) AS Policy_Year, SUM(`Premium Amount`) AS Total_Premium
    FROM policy_details
    GROUP BY YEAR(`Policy Start Date`)
)
SELECT 
    Policy_Year, Total_Premium,
    CASE 
        WHEN Total_Premium > LAG(Total_Premium) OVER (ORDER BY Policy_Year) THEN ' Increasing'
        WHEN Total_Premium < LAG(Total_Premium) OVER (ORDER BY Policy_Year) THEN ' Decreasing'
        ELSE 'No Change / First Year'
    END AS Growth_Trend
FROM Yearly_Premium;

#20 Calculate the difference between the highest and lowest premium growth rates.
#20. Calculate the difference between the highest and lowest premium growth rates.

WITH Yearly_Premium AS (
    SELECT 
        YEAR(`Policy Start Date`) AS Policy_Year,
        SUM(`Premium Amount`) AS Total_Premium
    FROM policy_details
    GROUP BY YEAR(`Policy Start Date`)
),

Growth_Calculation AS (
    SELECT 
        Policy_Year,
        Total_Premium,
        LAG(Total_Premium) OVER (ORDER BY Policy_Year) AS Previous_Year_Premium
    FROM Yearly_Premium
),

Growth_Rates AS (
    SELECT 
        Policy_Year,
        ROUND(
            ((Total_Premium - Previous_Year_Premium) 
            / Previous_Year_Premium) * 100,
            2
        ) AS Growth_Rate
    FROM Growth_Calculation
    WHERE Previous_Year_Premium IS NOT NULL
)

SELECT 
    MAX(Growth_Rate) AS Highest_Growth_Rate,
    MIN(Growth_Rate) AS Lowest_Growth_Rate,
    ROUND(
        MAX(Growth_Rate) - MIN(Growth_Rate),
        2
    ) AS Growth_Rate_Difference
FROM Growth_Rates;


#21 What is the yearly trend of policies ending from 2016 to 2034?
SELECT YEAR(`Policy End Date`) AS End_Year, COUNT(*) AS Policies_Ending
FROM policy_details
WHERE YEAR(`Policy End Date`) BETWEEN 2016 AND 2034
GROUP BY YEAR(`Policy End Date`)
ORDER BY End_Year;











